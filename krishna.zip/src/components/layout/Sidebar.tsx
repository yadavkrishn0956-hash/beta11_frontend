import React from 'react';
import { Icon, IconName } from '../shared/Icon';

interface MenuItem {
  id: string;
  label: string;
  icon: IconName;
  path: string;
}

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

const menuItems: MenuItem[] = [
  { id: 'overview', label: 'Overview', icon: 'dashboard', path: '/' },
  { id: 'records', label: 'Records', icon: 'records', path: '/records' },
  { id: 'ai-center', label: 'AI Center', icon: 'dashboard', path: '/ai-center' },
  { id: 'access', label: 'Access', icon: 'user', path: '/access' },
  { id: 'emergency', label: 'Emergency', icon: 'warning', path: '/emergency' },
  { id: 'logs', label: 'Logs', icon: 'records', path: '/logs' },
  { id: 'interop', label: 'Interop', icon: 'settings', path: '/interop' },
  { id: 'feedback', label: 'Feedback', icon: 'info', path: '/feedback' },
  { id: 'profile', label: 'Profile', icon: 'user', path: '/profile' },
];

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={onToggle}
          aria-hidden="true"
        />
      )}
      
      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
        aria-label="Main navigation"
      >
        <nav className="h-full overflow-y-auto py-4">
          <ul role="list" className="space-y-1 px-3">
            {menuItems.map((item) => (
              <li key={item.id}>
                <a
                  href={item.path}
                  className="flex items-center gap-3 px-3 py-2 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors group"
                  aria-label={item.label}
                >
                  <Icon name={item.icon} size={20} className="text-gray-500 group-hover:text-primary" />
                  <span className="font-medium">{item.label}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
    </>
  );
};
